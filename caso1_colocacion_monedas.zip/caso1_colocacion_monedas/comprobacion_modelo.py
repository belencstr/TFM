# ============================================================
# CASO 1 - COMPROBACIÓN DEL MODELO ACTUAL
# ============================================================
#
# Ejecuta todo lo implementado hasta ahora sobre el Mapa B:
#   1. Carga el mapa.
#   2. Extrae candidatas.
#   3. Construye el grafo.
#   4. Construye matrices de distancias.
#   5. Imprime comprobaciones básicas.
#
# NO resuelve todavía ningún problema de optimización.
# ============================================================

from mapas.mapa_b import MAPA_B
from modelo.candidatas import (
    obtener_candidatas,
    obtener_inicio_fin,
)
from modelo.grafo import (
    construir_grafo,
    resumen_grafo,
)
from modelo.distancias import (
    construir_matrices_distancia,
    comprobar_matriz_simetrica,
)


def main():
    print("=" * 65)
    print("CASO 1 - COMPROBACIÓN DEL MODELO ACTUAL")
    print("=" * 65)

    # 1. Mapa
    mapa = MAPA_B
    print(f"Mapa: B")
    print(f"Dimensiones: {len(mapa)} x {len(mapa[0])}")

    # 2. Candidatas
    candidatas = obtener_candidatas(mapa)
    inicio, fin = obtener_inicio_fin(mapa)

    print(f"Inicio: {inicio}")
    print(f"Fin: {fin}")
    print(f"Posiciones candidatas |C|: {len(candidatas)}")

    # 3. Grafo
    grafo = construir_grafo(mapa)
    resumen = resumen_grafo(grafo)

    print()
    print("GRAFO DE NAVEGACIÓN")
    print(f"Nodos transitables: {resumen['nodos']}")
    print(f"Aristas: {resumen['aristas']}")
    print(f"Mapa conexo: {resumen['conexo']}")

    # 4. Distancias
    print()
    print("Calculando matrices de distancias...")

    matrices = construir_matrices_distancia(
        candidatas,
        grafo,
    )

    matriz_euclidea = matrices["euclidea"]
    matriz_navegable = matrices["navegable"]

    print("Matrices calculadas.")

    # 5. Comprobaciones
    print()
    print("COMPROBACIONES")
    print(
        "Matriz euclídea simétrica:",
        comprobar_matriz_simetrica(matriz_euclidea),
    )
    print(
        "Matriz navegable simétrica:",
        comprobar_matriz_simetrica(matriz_navegable),
    )

    # Algunos ejemplos concretos para verificar resultados.
    ejemplos = [
        (0, 1),     # C001 - C002
        (0, 20),    # C001 - C021
        (10, 100),  # C011 - C101
        (50, 150),  # C051 - C151
    ]

    print()
    print("EJEMPLOS DE DISTANCIAS")

    for i, j in ejemplos:
        if i >= len(candidatas) or j >= len(candidatas):
            continue

        candidata_i = candidatas[i]
        candidata_j = candidatas[j]

        print(
            f"{candidata_i['id']} {candidata_i['fila'], candidata_i['columna']}"
            f" -> "
            f"{candidata_j['id']} {candidata_j['fila'], candidata_j['columna']}"
        )

        print(
            f"  Euclídea:  {matriz_euclidea[i][j]:.3f}"
        )

        print(
            f"  Navegable: {matriz_navegable[i][j]}"
        )

    print()
    print("=" * 65)
    print("Comprobación terminada correctamente.")
    print("Todavía no se ha ejecutado ningún solver.")
    print("=" * 65)


if __name__ == "__main__":
    main()