# ============================================================
# CASO 1 - COMPARACIÓN DE d_min EN EL MAPA B
# ============================================================
#
# Compara:
#   - sin restricción de separación mínima;
#   - d_min = 3;
#   - d_min = 4;
#   - d_min = 5.
#
# Para cada caso informa:
#   - valor objetivo total;
#   - separación mínima obtenida;
#   - posiciones seleccionadas;
#   - distancias entre parejas;
#   - validez respecto a incompatibilidades.
# ============================================================

import sys
from pathlib import Path

RAIZ_PROYECTO = Path(__file__).resolve().parent.parent

if str(RAIZ_PROYECTO) not in sys.path:
    sys.path.insert(0, str(RAIZ_PROYECTO))


from mapas.mapa_b import MAPA_B
from modelo.candidatas import obtener_candidatas
from modelo.grafo import construir_grafo
from modelo.distancias import construir_matriz_navegable

from modelo.incompatibilidades import (
    obtener_parejas_incompatibles,
    construir_conjunto_incompatibilidades,
)

from solvers.clasico import resolver_clasico


K = 5
VALORES_D_MIN = [None, 3, 4, 5]


def separacion_minima(indices, matriz):
    """
    Menor distancia entre cualquier pareja seleccionada.
    """
    menor = None

    for i in range(len(indices)):
        for j in range(i + 1, len(indices)):
            distancia = matriz[indices[i]][indices[j]]

            if menor is None or distancia < menor:
                menor = distancia

    return menor


def mostrar_resultado(
    etiqueta,
    resultado,
    candidatas,
    matriz,
    numero_incompatibilidades,
):
    print("=" * 76)
    print(etiqueta)
    print("=" * 76)

    print(f"k: {resultado['k']}")
    print(f"Valor objetivo total: {resultado['valor_objetivo']}")
    print(
        "Separación mínima obtenida:",
        separacion_minima(resultado["indices"], matriz),
    )
    print(
        "Parejas incompatibles definidas:",
        numero_incompatibilidades,
    )
    print(
        "Solución válida:",
        resultado["respeta_incompatibilidades"],
    )

    print()
    print("Posiciones seleccionadas:")

    for indice in resultado["indices"]:
        candidata = candidatas[indice]
        print(
            f"  {candidata['id']} -> "
            f"(fila={candidata['fila']}, columna={candidata['columna']})"
        )

    print()
    print("Distancias entre monedas:")

    indices = resultado["indices"]

    for i in range(len(indices)):
        for j in range(i + 1, len(indices)):

            a = indices[i]
            b = indices[j]

            print(
                f"  {candidatas[a]['id']} - "
                f"{candidatas[b]['id']}: "
                f"{matriz[a][b]}"
            )

    print()


def main():
    print("=" * 76)
    print("CASO 1 - COMPARACIÓN DE DISTANCIA MÍNIMA - MAPA B")
    print("=" * 76)

    candidatas = obtener_candidatas(MAPA_B)
    grafo = construir_grafo(MAPA_B)

    print(f"Candidatas: {len(candidatas)}")
    print(f"k: {K}")
    print()
    print("Calculando matriz navegable...")

    matriz = construir_matriz_navegable(
        candidatas,
        grafo,
    )

    print("Matriz calculada.")
    print()

    resumen_final = []

    for d_min in VALORES_D_MIN:

        if d_min is None:
            etiqueta = "SIN RESTRICCIÓN DE DISTANCIA MÍNIMA"
            parejas = []
            incompatibilidades = set()
        else:
            etiqueta = f"d_min = {d_min}"

            parejas = obtener_parejas_incompatibles(
                candidatas=candidatas,
                matriz_distancias=matriz,
                distancia_minima=d_min,
            )

            incompatibilidades = construir_conjunto_incompatibilidades(
                parejas
            )

        resultado = resolver_clasico(
            candidatas=candidatas,
            matriz_distancias=matriz,
            k=K,
            conjunto_incompatibilidades=incompatibilidades,
            usar_todos_los_inicios=True,
        )

        minima = separacion_minima(
            resultado["indices"],
            matriz,
        )

        mostrar_resultado(
            etiqueta=etiqueta,
            resultado=resultado,
            candidatas=candidatas,
            matriz=matriz,
            numero_incompatibilidades=len(parejas),
        )

        resumen_final.append(
            {
                "caso": (
                    "sin_d_min"
                    if d_min is None
                    else f"d_min_{d_min}"
                ),
                "valor_objetivo": resultado["valor_objetivo"],
                "separacion_minima": minima,
                "numero_incompatibilidades": len(parejas),
                "ids": resultado["ids"],
            }
        )

    print("=" * 76)
    print("RESUMEN COMPARATIVO")
    print("=" * 76)

    print(
        f"{'Caso':<15}"
        f"{'Objetivo':>12}"
        f"{'Sep. mínima':>15}"
        f"{'Incompat.':>14}"
    )

    print("-" * 56)

    for fila in resumen_final:
        print(
            f"{fila['caso']:<15}"
            f"{fila['valor_objetivo']:>12}"
            f"{fila['separacion_minima']:>15}"
            f"{fila['numero_incompatibilidades']:>14}"
        )

    print()
    print("Comparación terminada.")
    print("Todavía no se ha visualizado la solución en Blender.")


if __name__ == "__main__":
    main()