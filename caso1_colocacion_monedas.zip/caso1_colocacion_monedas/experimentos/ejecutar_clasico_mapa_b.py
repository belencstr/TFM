# ============================================================
# CASO 1 - EJECUCIÓN CLÁSICA SOBRE EL MAPA B
# ============================================================
#
# Flujo:
#   Mapa B
#       -> candidatas
#       -> grafo
#       -> matriz de distancias navegables
#       -> solver clásico heurístico
#
# Instancia inicial:
#   k = 5 monedas
#
# Este archivo NO modifica Blender y NO ejecuta todavía QUBO.
# ============================================================

import sys
from pathlib import Path

# Añadimos la raíz del proyecto al path para poder importar
# mapas/, modelo/ y solvers/ aunque este script esté dentro
# de experimentos/.
RAIZ_PROYECTO = Path(__file__).resolve().parent.parent

if str(RAIZ_PROYECTO) not in sys.path:
    sys.path.insert(0, str(RAIZ_PROYECTO))


from mapas.mapa_b import MAPA_B

from modelo.candidatas import (
    obtener_candidatas,
    obtener_inicio_fin,
)

from modelo.grafo import (
    construir_grafo,
    resumen_grafo,
)

from modelo.distancias import (
    construir_matriz_navegable,
)

from solvers.clasico import (
    resolver_clasico,
)


K = 5


def main():
    print("=" * 70)
    print("CASO 1 - SOLUCIÓN CLÁSICA - MAPA B")
    print("=" * 70)

    # --------------------------------------------------------
    # 1. Cargar instancia
    # --------------------------------------------------------
    mapa = MAPA_B
    candidatas = obtener_candidatas(mapa)
    inicio, fin = obtener_inicio_fin(mapa)

    print(f"Mapa: B")
    print(f"Dimensiones: {len(mapa)} x {len(mapa[0])}")
    print(f"Inicio: {inicio}")
    print(f"Fin: {fin}")
    print(f"Número de candidatas |C|: {len(candidatas)}")
    print(f"Número de monedas k: {K}")

    # --------------------------------------------------------
    # 2. Construir grafo
    # --------------------------------------------------------
    grafo = construir_grafo(mapa)
    resumen = resumen_grafo(grafo)

    print()
    print("GRAFO")
    print(f"Nodos: {resumen['nodos']}")
    print(f"Aristas: {resumen['aristas']}")
    print(f"Conexo: {resumen['conexo']}")

    if not resumen["conexo"]:
        raise ValueError(
            "El mapa no es conexo. No continuamos con la optimización."
        )

    # --------------------------------------------------------
    # 3. Construir matriz D navegable
    # --------------------------------------------------------
    print()
    print("Calculando matriz de distancias navegables...")

    matriz_navegable = construir_matriz_navegable(
        candidatas,
        grafo,
    )

    print("Matriz calculada.")

    # --------------------------------------------------------
    # 4. Resolver clásicamente
    # --------------------------------------------------------
    print()
    print("Ejecutando solver clásico heurístico...")

    resultado = resolver_clasico(
        candidatas=candidatas,
        matriz_distancias=matriz_navegable,
        k=K,
        usar_todos_los_inicios=True,
    )

    print("Solver terminado.")

    # --------------------------------------------------------
    # 5. Mostrar resultado
    # --------------------------------------------------------
    print()
    print("=" * 70)
    print("RESULTADO")
    print("=" * 70)

    print(f"Método: {resultado['metodo']}")
    print(f"k: {resultado['k']}")
    print(f"Valor objetivo: {resultado['valor_objetivo']}")

    print()
    print("POSICIONES SELECCIONADAS")

    for indice in resultado["indices"]:
        candidata = candidatas[indice]

        print(
            f"  {candidata['id']} -> "
            f"(fila={candidata['fila']}, columna={candidata['columna']})"
        )

    # --------------------------------------------------------
    # 6. Distancias entre las monedas elegidas
    # --------------------------------------------------------
    print()
    print("DISTANCIAS NAVEGABLES ENTRE LAS MONEDAS")

    indices = resultado["indices"]

    for i in range(len(indices)):
        for j in range(i + 1, len(indices)):
            indice_a = indices[i]
            indice_b = indices[j]

            candidata_a = candidatas[indice_a]
            candidata_b = candidatas[indice_b]

            distancia = matriz_navegable[indice_a][indice_b]

            print(
                f"  {candidata_a['id']} - {candidata_b['id']}: "
                f"{distancia}"
            )

    print()
    print("=" * 70)
    print("Ejecución clásica terminada correctamente.")
    print("=" * 70)


if __name__ == "__main__":
    main()