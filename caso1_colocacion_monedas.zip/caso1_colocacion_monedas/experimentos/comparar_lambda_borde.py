# ============================================================
# CASO 1 - COMPARACIÓN DE PENALIZACIÓN DE BORDE - MAPA B
# ============================================================
#
# Se fija:
#   k = 5
#   d_min = 5
#   radio_borde = 3
#
# Se comparan distintos lambda_borde.
# ============================================================

import sys
from pathlib import Path

RAIZ_PROYECTO = Path(__file__).resolve().parent.parent

if str(RAIZ_PROYECTO) not in sys.path:
    sys.path.insert(0, str(RAIZ_PROYECTO))


from mapas.mapa_b import MAPA_B
from modelo.candidatas import obtener_candidatas
from modelo.grafo import construir_grafo
from modelo.distancias import construir_matriz_navegable

from modelo.incompatibilidades import (
    obtener_parejas_incompatibles,
    construir_conjunto_incompatibilidades,
)

from modelo.bordes import construir_penalizaciones_borde

from solvers.clasico_balanceado import (
    resolver_clasico_balanceado,
)


K = 5
D_MIN = 5
RADIO_BORDE = 3

LAMBDAS = [
    0.00,
    0.05,
    0.10,
    0.20,
    0.30,
]


def main():
    print("=" * 80)
    print("CASO 1 - EFECTO DE LA PENALIZACIÓN DE BORDE - MAPA B")
    print("=" * 80)

    candidatas = obtener_candidatas(MAPA_B)
    grafo = construir_grafo(MAPA_B)

    matriz = construir_matriz_navegable(
        candidatas,
        grafo,
    )

    parejas = obtener_parejas_incompatibles(
        candidatas=candidatas,
        matriz_distancias=matriz,
        distancia_minima=D_MIN,
    )

    incompatibilidades = construir_conjunto_incompatibilidades(
        parejas
    )

    penalizaciones = construir_penalizaciones_borde(
        candidatas=candidatas,
        mapa=MAPA_B,
        radio=RADIO_BORDE,
    )

    print(f"Candidatas: {len(candidatas)}")
    print(f"k: {K}")
    print(f"d_min: {D_MIN}")
    print(f"Radio de penalización de borde: {RADIO_BORDE}")
    print(f"Incompatibilidades: {len(parejas)}")
    print()

    resultados = []

    for lambda_borde in LAMBDAS:

        resultado = resolver_clasico_balanceado(
            candidatas=candidatas,
            matriz_distancias=matriz,
            penalizaciones_borde=penalizaciones,
            k=K,
            lambda_borde=lambda_borde,
            incompatibilidades=incompatibilidades,
        )

        resultados.append(resultado)

        print("-" * 80)
        print(f"lambda_borde = {lambda_borde:.2f}")
        print(
            f"Separación total: "
            f"{resultado['separacion_total']}"
        )
        print(
            f"Separación mínima: "
            f"{resultado['separacion_minima']}"
        )
        print(
            f"Penalización media de borde: "
            f"{resultado['penalizacion_media_borde']:.3f}"
        )
        print(
            f"Valor balanceado: "
            f"{resultado['valor_balanceado']:.6f}"
        )

        print("Posiciones:")

        for indice in resultado["indices"]:
            candidata = candidatas[indice]

            print(
                f"  {candidata['id']} -> "
                f"(fila={candidata['fila']}, "
                f"columna={candidata['columna']}, "
                f"p_borde={penalizaciones[indice]:.2f})"
            )

    print()
    print("=" * 80)
    print("RESUMEN")
    print("=" * 80)

    print(
        f"{'lambda':>8}"
        f"{'sep.total':>12}"
        f"{'sep.min':>10}"
        f"{'pen.borde':>12}"
        f"{'F':>12}"
    )

    print("-" * 54)

    for resultado in resultados:
        print(
            f"{resultado['lambda_borde']:>8.2f}"
            f"{resultado['separacion_total']:>12}"
            f"{resultado['separacion_minima']:>10}"
            f"{resultado['penalizacion_media_borde']:>12.3f}"
            f"{resultado['valor_balanceado']:>12.5f}"
        )

    print()
    print("Análisis terminado.")
    print(
        "No se elegirá lambda definitivamente hasta "
        "comparar los resultados numérica y visualmente."
    )


if __name__ == "__main__":
    main()