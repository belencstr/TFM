# ============================================================
# CASO 1 - ANÁLISIS DE DISTANCIA MÍNIMA EN EL MAPA B
# ============================================================
#
# Compara varios valores de d_min:
#
#   d_min = 3
#   d_min = 4
#   d_min = 5
#
# Una pareja es incompatible si:
#
#       D[i][j] < d_min
#
# Este experimento NO modifica todavía el solver clásico.
# Su objetivo es estudiar el efecto del umbral antes de fijarlo.
# ============================================================

import sys
from pathlib import Path

RAIZ_PROYECTO = Path(__file__).resolve().parent.parent

if str(RAIZ_PROYECTO) not in sys.path:
    sys.path.insert(0, str(RAIZ_PROYECTO))


from mapas.mapa_b import MAPA_B

from modelo.candidatas import obtener_candidatas

from modelo.grafo import construir_grafo

from modelo.distancias import construir_matriz_navegable

from modelo.incompatibilidades import (
    obtener_parejas_incompatibles,
    resumen_incompatibilidades,
)


VALORES_D_MIN = [3, 4, 5]


def main():
    print("=" * 72)
    print("CASO 1 - ANÁLISIS DE d_min - MAPA B")
    print("=" * 72)

    mapa = MAPA_B
    candidatas = obtener_candidatas(mapa)
    grafo = construir_grafo(mapa)

    print(f"Número de candidatas: {len(candidatas)}")
    print()
    print("Calculando matriz de distancias navegables...")

    matriz = construir_matriz_navegable(
        candidatas,
        grafo,
    )

    print("Matriz calculada.")
    print()

    for distancia_minima in VALORES_D_MIN:

        parejas = obtener_parejas_incompatibles(
            candidatas=candidatas,
            matriz_distancias=matriz,
            distancia_minima=distancia_minima,
        )

        resumen = resumen_incompatibilidades(
            parejas,
            distancia_minima,
        )

        print("-" * 72)
        print(f"d_min = {distancia_minima}")
        print(
            "Parejas incompatibles:",
            resumen["numero_parejas_incompatibles"],
        )
        print(
            "Menor distancia incompatible:",
            resumen["menor_distancia_detectada"],
        )
        print(
            "Mayor distancia incompatible:",
            resumen["mayor_distancia_incompatible"],
        )

        print()
        print("Primeras 10 parejas incompatibles:")

        for pareja in parejas[:10]:
            print(
                f"  {pareja['id_i']} - {pareja['id_j']} "
                f"(distancia={pareja['distancia']})"
            )

        print()

    print("=" * 72)
    print("Análisis terminado.")
    print("Todavía no se ha impuesto d_min al solver clásico.")
    print("=" * 72)


if __name__ == "__main__":
    main()