# ============================================================
# CASO 1 - SOLVER CLÁSICO CON PENALIZACIÓN DE BORDE
# ============================================================
#
# Función objetivo:
#
#   F = separación_normalizada
#       - lambda_borde * penalización_media_borde
#
# donde:
#
#   separación_normalizada =
#       media de las distancias seleccionadas / D_max
#
#   penalización_media_borde =
#       media de p_i para las candidatas seleccionadas
#
# Se mantienen las incompatibilidades por d_min.
#
# Método:
#   greedy multiinicio + búsqueda local 1-swap.
#
# Sigue siendo una heurística: no garantiza óptimo global.
# ============================================================


def calcular_dmax(matriz_distancias):
    """
    Mayor distancia existente en la matriz D.
    """
    return max(
        max(fila)
        for fila in matriz_distancias
    )


def separacion_total(indices, matriz_distancias):
    """
    Suma bruta de distancias entre parejas seleccionadas.
    Se conserva como métrica de resultados.
    """
    total = 0

    for i in range(len(indices)):
        for j in range(i + 1, len(indices)):
            total += matriz_distancias[
                indices[i]
            ][
                indices[j]
            ]

    return total


def separacion_minima(indices, matriz_distancias):
    """
    Menor distancia entre dos seleccionadas.
    """
    menor = None

    for i in range(len(indices)):
        for j in range(i + 1, len(indices)):
            distancia = matriz_distancias[
                indices[i]
            ][
                indices[j]
            ]

            if menor is None or distancia < menor:
                menor = distancia

    return menor


def son_incompatibles(a, b, incompatibilidades):
    if not incompatibilidades:
        return False

    i, j = sorted((a, b))
    return (i, j) in incompatibilidades


def seleccion_valida(indices, incompatibilidades):
    for i in range(len(indices)):
        for j in range(i + 1, len(indices)):
            if son_incompatibles(
                indices[i],
                indices[j],
                incompatibilidades,
            ):
                return False

    return True


def candidato_compatible(
    candidato,
    seleccionados,
    incompatibilidades,
):
    return all(
        not son_incompatibles(
            candidato,
            seleccionado,
            incompatibilidades,
        )
        for seleccionado in seleccionados
    )


def valor_balanceado(
    indices,
    matriz_distancias,
    penalizaciones_borde,
    lambda_borde,
    dmax,
):
    """
    Calcula la función objetivo normalizada.

    Con k fijo, usar media o suma de distancias produce el mismo
    orden para la parte de separación. La media normalizada
    facilita combinarla con una penalización en [0,1].
    """
    k = len(indices)

    if k < 2:
        separacion_norm = 0.0
    else:
        numero_parejas = k * (k - 1) / 2

        separacion_norm = (
            separacion_total(indices, matriz_distancias)
            / numero_parejas
            / dmax
        )

    penalizacion_media = (
        sum(
            penalizaciones_borde[i]
            for i in indices
        )
        / k
    )

    return (
        separacion_norm
        - lambda_borde * penalizacion_media
    )


def construir_greedy(
    matriz_distancias,
    penalizaciones_borde,
    k,
    inicio,
    lambda_borde,
    incompatibilidades,
    dmax,
):
    n = len(matriz_distancias)

    seleccionados = [inicio]
    restantes = set(range(n))
    restantes.remove(inicio)

    while len(seleccionados) < k:

        mejor = None
        mejor_valor = None

        for candidato in restantes:

            if not candidato_compatible(
                candidato,
                seleccionados,
                incompatibilidades,
            ):
                continue

            propuesta = seleccionados + [candidato]

            valor = valor_balanceado(
                propuesta,
                matriz_distancias,
                penalizaciones_borde,
                lambda_borde,
                dmax,
            )

            if mejor_valor is None or valor > mejor_valor:
                mejor = candidato
                mejor_valor = valor

        if mejor is None:
            return None

        seleccionados.append(mejor)
        restantes.remove(mejor)

    return seleccionados


def mejorar_1swap(
    seleccionados,
    matriz_distancias,
    penalizaciones_borde,
    lambda_borde,
    incompatibilidades,
    dmax,
):
    n = len(matriz_distancias)

    seleccionados = list(seleccionados)
    seleccionados_set = set(seleccionados)

    mejor_valor = valor_balanceado(
        seleccionados,
        matriz_distancias,
        penalizaciones_borde,
        lambda_borde,
        dmax,
    )

    mejora = True

    while mejora:
        mejora = False
        mejor_cambio = None
        mejor_valor_cambio = mejor_valor

        no_seleccionados = [
            i for i in range(n)
            if i not in seleccionados_set
        ]

        for posicion, sale in enumerate(seleccionados):

            resto = (
                seleccionados[:posicion]
                + seleccionados[posicion + 1:]
            )

            for entra in no_seleccionados:

                if not candidato_compatible(
                    entra,
                    resto,
                    incompatibilidades,
                ):
                    continue

                propuesta = seleccionados.copy()
                propuesta[posicion] = entra

                valor = valor_balanceado(
                    propuesta,
                    matriz_distancias,
                    penalizaciones_borde,
                    lambda_borde,
                    dmax,
                )

                if valor > mejor_valor_cambio:
                    mejor_valor_cambio = valor
                    mejor_cambio = (
                        posicion,
                        sale,
                        entra,
                    )

        if mejor_cambio is not None:
            posicion, sale, entra = mejor_cambio

            seleccionados[posicion] = entra
            seleccionados_set.remove(sale)
            seleccionados_set.add(entra)

            mejor_valor = mejor_valor_cambio
            mejora = True

    return seleccionados


def resolver_clasico_balanceado(
    candidatas,
    matriz_distancias,
    penalizaciones_borde,
    k,
    lambda_borde,
    incompatibilidades=None,
):
    """
    Ejecuta greedy desde todas las candidatas y aplica 1-swap.
    """
    n = len(candidatas)

    if len(matriz_distancias) != n:
        raise ValueError(
            "La matriz D no coincide con el número de candidatas."
        )

    if len(penalizaciones_borde) != n:
        raise ValueError(
            "Las penalizaciones no coinciden con las candidatas."
        )

    if not 0 <= lambda_borde:
        raise ValueError("lambda_borde debe ser >= 0.")

    dmax = calcular_dmax(matriz_distancias)

    mejor = None
    mejor_valor = None

    for inicio in range(n):

        seleccion = construir_greedy(
            matriz_distancias=matriz_distancias,
            penalizaciones_borde=penalizaciones_borde,
            k=k,
            inicio=inicio,
            lambda_borde=lambda_borde,
            incompatibilidades=incompatibilidades,
            dmax=dmax,
        )

        if seleccion is None:
            continue

        valor = valor_balanceado(
            seleccion,
            matriz_distancias,
            penalizaciones_borde,
            lambda_borde,
            dmax,
        )

        if mejor_valor is None or valor > mejor_valor:
            mejor = seleccion
            mejor_valor = valor

    if mejor is None:
        raise ValueError(
            "No se encontró ninguna solución factible."
        )

    mejor = mejorar_1swap(
        seleccionados=mejor,
        matriz_distancias=matriz_distancias,
        penalizaciones_borde=penalizaciones_borde,
        lambda_borde=lambda_borde,
        incompatibilidades=incompatibilidades,
        dmax=dmax,
    )

    mejor = sorted(mejor)

    return {
        "indices": mejor,
        "ids": [
            candidatas[i]["id"]
            for i in mejor
        ],
        "valor_balanceado": valor_balanceado(
            mejor,
            matriz_distancias,
            penalizaciones_borde,
            lambda_borde,
            dmax,
        ),
        "separacion_total": separacion_total(
            mejor,
            matriz_distancias,
        ),
        "separacion_minima": separacion_minima(
            mejor,
            matriz_distancias,
        ),
        "penalizacion_media_borde": (
            sum(
                penalizaciones_borde[i]
                for i in mejor
            )
            / k
        ),
        "lambda_borde": lambda_borde,
        "k": k,
        "valida": seleccion_valida(
            mejor,
            incompatibilidades,
        ),
    }