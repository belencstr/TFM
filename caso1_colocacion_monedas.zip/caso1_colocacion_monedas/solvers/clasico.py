# ============================================================
# CASO 1 - SOLVER CLÁSICO HEURÍSTICO
# ============================================================
#
# Objetivo:
#   Seleccionar exactamente k posiciones candidatas maximizando
#   la suma de distancias entre todas las parejas seleccionadas.
#
# Estrategia:
#   1. Construcción greedy.
#   2. Repetición desde varios puntos iniciales.
#   3. Búsqueda local mediante intercambios 1-a-1.
#
# Opcionalmente puede recibir un conjunto de parejas
# incompatibles. Si se proporciona, ninguna solución construida
# o aceptada podrá contener una de esas parejas.
#
# IMPORTANTE:
#   Este método es heurístico. No garantiza el óptimo global.
# ============================================================


def valor_objetivo(indices_seleccionados, matriz_distancias):
    """
    Suma de distancias entre todas las parejas seleccionadas.
    """
    total = 0

    for i in range(len(indices_seleccionados)):
        for j in range(i + 1, len(indices_seleccionados)):
            a = indices_seleccionados[i]
            b = indices_seleccionados[j]
            total += matriz_distancias[a][b]

    return total


def son_incompatibles(
    indice_i,
    indice_j,
    conjunto_incompatibilidades,
):
    """
    Comprueba si dos candidatas forman una pareja incompatible.
    """
    if not conjunto_incompatibilidades:
        return False

    a, b = sorted((indice_i, indice_j))
    return (a, b) in conjunto_incompatibilidades


def candidato_es_compatible(
    candidato,
    seleccionados,
    conjunto_incompatibilidades,
):
    """
    Comprueba si 'candidato' puede añadirse a la selección actual
    sin violar ninguna incompatibilidad.
    """
    return all(
        not son_incompatibles(
            candidato,
            seleccionado,
            conjunto_incompatibilidades,
        )
        for seleccionado in seleccionados
    )


def seleccion_es_valida(
    seleccionados,
    conjunto_incompatibilidades,
):
    """
    Comprueba que no exista ninguna pareja incompatible
    dentro de la selección.
    """
    for i in range(len(seleccionados)):
        for j in range(i + 1, len(seleccionados)):
            if son_incompatibles(
                seleccionados[i],
                seleccionados[j],
                conjunto_incompatibilidades,
            ):
                return False

    return True


def incremento_al_añadir(
    candidato,
    seleccionados,
    matriz_distancias,
):
    """
    Incremento del objetivo al añadir una candidata.
    """
    return sum(
        matriz_distancias[candidato][seleccionado]
        for seleccionado in seleccionados
    )


def construir_greedy(
    matriz_distancias,
    k,
    inicio,
    conjunto_incompatibilidades=None,
):
    """
    Construye una solución greedy desde una candidata inicial.

    Si las incompatibilidades hacen imposible completar k
    elementos desde ese inicio, devuelve None.
    """
    n = len(matriz_distancias)

    if k <= 0:
        raise ValueError("k debe ser mayor que 0.")

    if k > n:
        raise ValueError(
            f"No se pueden seleccionar {k} posiciones de solo {n} candidatas."
        )

    seleccionados = [inicio]
    no_seleccionados = set(range(n))
    no_seleccionados.remove(inicio)

    while len(seleccionados) < k:

        mejor_candidato = None
        mejor_incremento = None

        for candidato in no_seleccionados:

            if not candidato_es_compatible(
                candidato,
                seleccionados,
                conjunto_incompatibilidades,
            ):
                continue

            incremento = incremento_al_añadir(
                candidato,
                seleccionados,
                matriz_distancias,
            )

            if (
                mejor_incremento is None
                or incremento > mejor_incremento
            ):
                mejor_incremento = incremento
                mejor_candidato = candidato

        # Desde este inicio no existe forma greedy de completar k.
        if mejor_candidato is None:
            return None

        seleccionados.append(mejor_candidato)
        no_seleccionados.remove(mejor_candidato)

    return seleccionados


def mejorar_por_intercambios(
    seleccionados,
    matriz_distancias,
    conjunto_incompatibilidades=None,
):
    """
    Búsqueda local mediante intercambios 1-a-1.

    Solo se aceptan soluciones válidas respecto a las
    incompatibilidades.
    """
    n = len(matriz_distancias)

    seleccionados = list(seleccionados)
    seleccionados_set = set(seleccionados)

    if not seleccion_es_valida(
        seleccionados,
        conjunto_incompatibilidades,
    ):
        raise ValueError(
            "La solución inicial de búsqueda local no es válida."
        )

    mejor_valor = valor_objetivo(
        seleccionados,
        matriz_distancias,
    )

    hubo_mejora = True

    while hubo_mejora:
        hubo_mejora = False

        mejor_intercambio = None
        mejor_valor_intercambio = mejor_valor

        no_seleccionados = [
            i for i in range(n)
            if i not in seleccionados_set
        ]

        for posicion_lista, seleccionado in enumerate(seleccionados):

            # Selección temporal sin el elemento que sale.
            resto = (
                seleccionados[:posicion_lista]
                + seleccionados[posicion_lista + 1:]
            )

            for candidato in no_seleccionados:

                if not candidato_es_compatible(
                    candidato,
                    resto,
                    conjunto_incompatibilidades,
                ):
                    continue

                nueva_seleccion = seleccionados.copy()
                nueva_seleccion[posicion_lista] = candidato

                nuevo_valor = valor_objetivo(
                    nueva_seleccion,
                    matriz_distancias,
                )

                if nuevo_valor > mejor_valor_intercambio:
                    mejor_valor_intercambio = nuevo_valor
                    mejor_intercambio = (
                        posicion_lista,
                        seleccionado,
                        candidato,
                    )

        if mejor_intercambio is not None:
            posicion_lista, sale, entra = mejor_intercambio

            seleccionados[posicion_lista] = entra

            seleccionados_set.remove(sale)
            seleccionados_set.add(entra)

            mejor_valor = mejor_valor_intercambio
            hubo_mejora = True

    return seleccionados, mejor_valor


def resolver_clasico(
    candidatas,
    matriz_distancias,
    k,
    conjunto_incompatibilidades=None,
    usar_todos_los_inicios=True,
    max_inicios=None,
):
    """
    Resuelve heurísticamente el problema.

    Si 'conjunto_incompatibilidades' es None o vacío, resuelve
    el problema original sin separación mínima.

    Si contiene pares (i, j), nunca selecciona conjuntamente
    dichas candidatas.
    """
    n = len(candidatas)

    if len(matriz_distancias) != n:
        raise ValueError(
            "El número de candidatas y el tamaño de la matriz "
            "de distancias no coinciden."
        )

    if k <= 0 or k > n:
        raise ValueError(
            f"k debe estar entre 1 y {n}. Valor recibido: {k}"
        )

    if usar_todos_los_inicios:
        inicios = list(range(n))
    else:
        if max_inicios is None:
            max_inicios = min(20, n)

        inicios = list(range(min(max_inicios, n)))

    mejor_seleccion = None
    mejor_valor = None

    for inicio in inicios:

        seleccion = construir_greedy(
            matriz_distancias=matriz_distancias,
            k=k,
            inicio=inicio,
            conjunto_incompatibilidades=conjunto_incompatibilidades,
        )

        if seleccion is None:
            continue

        valor = valor_objetivo(
            seleccion,
            matriz_distancias,
        )

        if mejor_valor is None or valor > mejor_valor:
            mejor_valor = valor
            mejor_seleccion = seleccion

    if mejor_seleccion is None:
        raise ValueError(
            "No se ha encontrado ninguna solución factible "
            f"con k={k} y las incompatibilidades indicadas."
        )

    mejor_seleccion, mejor_valor = mejorar_por_intercambios(
        seleccionados=mejor_seleccion,
        matriz_distancias=matriz_distancias,
        conjunto_incompatibilidades=conjunto_incompatibilidades,
    )

    mejor_seleccion = sorted(mejor_seleccion)

    ids = [
        candidatas[i]["id"]
        for i in mejor_seleccion
    ]

    return {
        "indices": mejor_seleccion,
        "ids": ids,
        "valor_objetivo": mejor_valor,
        "k": k,
        "metodo": "greedy_multiinicio + busqueda_local_1swap",
        "respeta_incompatibilidades": seleccion_es_valida(
            mejor_seleccion,
            conjunto_incompatibilidades,
        ),
    }