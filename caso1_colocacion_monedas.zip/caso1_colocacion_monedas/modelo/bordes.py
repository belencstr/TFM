# ============================================================
# CASO 1 - PENALIZACIÓN SUAVE DEL PERÍMETRO EXTERIOR
# ============================================================
#
# Objetivo:
#   Desincentivar posiciones demasiado próximas al borde
#   exterior del mapa sin prohibirlas y sin penalizar los
#   obstáculos interiores.
#
# La penalización queda en [0, 1].
# Las esquinas reciben una penalización mayor que los laterales.
# ============================================================


def proximidad_borde(distancia_borde, radio):
    """
    Devuelve una proximidad normalizada al borde.

    Para radio=3:
        distancia 1 -> 1.0
        distancia 2 -> 0.5
        distancia 3 o más -> 0.0
    """
    if radio <= 1:
        raise ValueError("El radio de borde debe ser mayor que 1.")

    return max(
        0.0,
        (radio - distancia_borde) / (radio - 1),
    )


def penalizacion_borde_candidata(
    candidata,
    filas,
    columnas,
    radio=3,
):
    """
    Calcula una penalización suave respecto al perímetro exterior.

    Se consideran por separado:
      - proximidad al borde superior/inferior;
      - proximidad al borde izquierdo/derecho.

    Después se promedian.

    Consecuencia:
      - una candidata próxima a un único lateral se penaliza;
      - una candidata próxima a dos laterales (esquina) recibe
        una penalización mayor.

    Los obstáculos interiores NO influyen.
    """
    fila = candidata["fila"]
    columna = candidata["columna"]

    distancia_vertical = min(
        fila,
        filas - 1 - fila,
    )

    distancia_horizontal = min(
        columna,
        columnas - 1 - columna,
    )

    penal_vertical = proximidad_borde(
        distancia_vertical,
        radio,
    )

    penal_horizontal = proximidad_borde(
        distancia_horizontal,
        radio,
    )

    return (penal_vertical + penal_horizontal) / 2.0


def construir_penalizaciones_borde(
    candidatas,
    mapa,
    radio=3,
):
    """
    Devuelve una lista p donde p[i] corresponde a la penalización
    de borde de candidatas[i].
    """
    filas = len(mapa)
    columnas = len(mapa[0])

    return [
        penalizacion_borde_candidata(
            candidata,
            filas,
            columnas,
            radio,
        )
        for candidata in candidatas
    ]