# ============================================================
# CASO 1 - PAREJAS INCOMPATIBLES
# ============================================================
#
# Una pareja de candidatas (Ci, Cj) se considera incompatible
# si su distancia navegable es menor que una distancia mínima
# d_min.
#
# Condición:
#
#       D[i][j] < d_min
#
# Más adelante, estas parejas impondrán la restricción:
#
#       x_i + x_j <= 1
#
# Este módulo únicamente DETECTA las incompatibilidades.
# Todavía no modifica ningún solver ni construye el QUBO.
# ============================================================


def obtener_parejas_incompatibles(
    candidatas,
    matriz_distancias,
    distancia_minima,
):
    """
    Devuelve todas las parejas de candidatas cuya distancia
    es estrictamente menor que 'distancia_minima'.

    Args:
        candidatas:
            Lista de candidatas generada por candidatas.py.

        matriz_distancias:
            Matriz de distancias, normalmente la navegable.

        distancia_minima:
            Umbral mínimo permitido entre dos monedas.

    Returns:
        Lista de diccionarios con esta estructura:

        {
            "indice_i": 0,
            "indice_j": 14,
            "id_i": "C001",
            "id_j": "C015",
            "distancia": 2
        }
    """
    if distancia_minima <= 0:
        raise ValueError(
            "La distancia mínima debe ser mayor que 0."
        )

    n = len(candidatas)

    if len(matriz_distancias) != n:
        raise ValueError(
            "El número de candidatas no coincide con "
            "el tamaño de la matriz de distancias."
        )

    incompatibles = []

    for i in range(n):
        for j in range(i + 1, n):

            distancia = matriz_distancias[i][j]

            if distancia < distancia_minima:
                incompatibles.append(
                    {
                        "indice_i": i,
                        "indice_j": j,
                        "id_i": candidatas[i]["id"],
                        "id_j": candidatas[j]["id"],
                        "distancia": distancia,
                    }
                )

    return incompatibles


def construir_conjunto_incompatibilidades(
    parejas_incompatibles,
):
    """
    Convierte la lista detallada en un conjunto de pares
    de índices.

    Ejemplo:
        {(0, 14), (3, 8), ...}

    Este formato será cómodo para que el solver pueda
    comprobar rápidamente si una solución viola restricciones.
    """
    return {
        (pareja["indice_i"], pareja["indice_j"])
        for pareja in parejas_incompatibles
    }


def son_incompatibles(
    indice_i,
    indice_j,
    conjunto_incompatibilidades,
):
    """
    Comprueba si dos índices forman una pareja incompatible.
    """
    a, b = sorted((indice_i, indice_j))
    return (a, b) in conjunto_incompatibilidades


def seleccion_es_valida(
    indices_seleccionados,
    conjunto_incompatibilidades,
):
    """
    Comprueba si una selección contiene alguna pareja
    incompatible.
    """
    seleccion = list(indices_seleccionados)

    for i in range(len(seleccion)):
        for j in range(i + 1, len(seleccion)):

            if son_incompatibles(
                seleccion[i],
                seleccion[j],
                conjunto_incompatibilidades,
            ):
                return False

    return True


def resumen_incompatibilidades(
    parejas_incompatibles,
    distancia_minima,
):
    """
    Devuelve un resumen básico para documentar y comparar
    distintos valores de d_min.
    """
    if parejas_incompatibles:
        distancias = [
            pareja["distancia"]
            for pareja in parejas_incompatibles
        ]

        distancia_menor = min(distancias)
        distancia_mayor = max(distancias)
    else:
        distancia_menor = None
        distancia_mayor = None

    return {
        "distancia_minima": distancia_minima,
        "numero_parejas_incompatibles": len(
            parejas_incompatibles
        ),
        "menor_distancia_detectada": distancia_menor,
        "mayor_distancia_incompatible": distancia_mayor,
    }