import bpy
import sys
from pathlib import Path

# Permite importar módulos del proyecto al ejecutar este archivo desde Blender.
RAIZ = Path(bpy.path.abspath("//")).resolve()
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))

from mapas.mapa_b import MAPA_B
from modelo.candidatas import obtener_candidatas, obtener_inicio_fin

MAPA = MAPA_B

TAM_CELDA = 1.0
ALTURA_SUELO = 0.10
ALTURA_MURO = 1.25
RADIO_CANDIDATA = 0.10
ALTURA_CANDIDATA = 0.035


def limpiar_escena():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)

    for coleccion in list(bpy.data.collections):
        if coleccion.name == "Candidatas":
            bpy.data.collections.remove(coleccion)


def crear_material(nombre, color):
    material = bpy.data.materials.get(nombre)
    if material is None:
        material = bpy.data.materials.new(name=nombre)
    material.diffuse_color = color
    return material


def crear_cubo(nombre, posicion, escala, material):
    bpy.ops.mesh.primitive_cube_add(location=posicion)
    obj = bpy.context.active_object
    obj.name = nombre
    obj.scale = escala
    obj.data.materials.append(material)
    return obj


def mover_a_coleccion(objeto, coleccion):
    for col in list(objeto.users_collection):
        col.objects.unlink(objeto)
    coleccion.objects.link(objeto)


def crear_marcador(nombre, x, y, radio, altura, z, material, coleccion=None):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=24,
        radius=radio,
        depth=altura,
        location=(x, y, z),
    )
    obj = bpy.context.active_object
    obj.name = nombre
    obj.data.materials.append(material)

    if coleccion:
        mover_a_coleccion(obj, coleccion)

    return obj


def coordenadas_blender(fila, columna, filas, columnas):
    offset_x = (columnas - 1) / 2
    offset_y = (filas - 1) / 2
    return (
        (columna - offset_x) * TAM_CELDA,
        (offset_y - fila) * TAM_CELDA,
    )


def crear_escena():
    filas = len(MAPA)
    columnas = len(MAPA[0])

    suelo_mat = crear_material("Material_Suelo", (0.20, 0.32, 0.20, 1.0))
    muro_mat = crear_material("Material_Muro", (0.18, 0.20, 0.24, 1.0))
    inicio_mat = crear_material("Material_Inicio", (0.05, 0.65, 0.12, 1.0))
    fin_mat = crear_material("Material_Fin", (0.75, 0.08, 0.06, 1.0))
    candidata_mat = crear_material("Material_Candidata", (0.08, 0.30, 0.80, 1.0))

    coleccion_candidatas = bpy.data.collections.new("Candidatas")
    bpy.context.scene.collection.children.link(coleccion_candidatas)

    # Mapa
    for fila, contenido in enumerate(MAPA):
        for columna, celda in enumerate(contenido):
            x, y = coordenadas_blender(fila, columna, filas, columnas)

            crear_cubo(
                f"Suelo_{fila}_{columna}",
                (x, y, -ALTURA_SUELO / 2),
                (TAM_CELDA / 2, TAM_CELDA / 2, ALTURA_SUELO / 2),
                suelo_mat,
            )

            if celda == "#":
                crear_cubo(
                    f"Muro_{fila}_{columna}",
                    (x, y, ALTURA_MURO / 2),
                    (TAM_CELDA / 2, TAM_CELDA / 2, ALTURA_MURO / 2),
                    muro_mat,
                )
            elif celda == "S":
                crear_marcador("INICIO", x, y, 0.30, 0.12, 0.08, inicio_mat)
            elif celda == "E":
                crear_marcador("FIN", x, y, 0.30, 0.12, 0.08, fin_mat)

    # Candidatas
    candidatas = obtener_candidatas(MAPA)

    for candidata in candidatas:
        x, y = coordenadas_blender(
            candidata["fila"],
            candidata["columna"],
            filas,
            columnas,
        )

        obj = crear_marcador(
            candidata["id"],
            x,
            y,
            RADIO_CANDIDATA,
            ALTURA_CANDIDATA,
            ALTURA_CANDIDATA / 2 + 0.01,
            candidata_mat,
            coleccion_candidatas,
        )

        obj["id_candidata"] = candidata["id"]
        obj["fila"] = candidata["fila"]
        obj["columna"] = candidata["columna"]

    return candidatas


def crear_camara():
    filas = len(MAPA)
    columnas = len(MAPA[0])

    datos = bpy.data.cameras.new("Camara_Mapa")
    camara = bpy.data.objects.new("Camara_Mapa", datos)
    bpy.context.collection.objects.link(camara)

    camara.location = (0.0, 0.0, 25.0)
    datos.type = "ORTHO"
    datos.ortho_scale = max(filas, columnas) + 2
    bpy.context.scene.camera = camara


def crear_luz():
    datos = bpy.data.lights.new("Luz_Mapa", type="AREA")
    datos.energy = 1800
    datos.shape = "DISK"
    datos.size = 15.0

    luz = bpy.data.objects.new("Luz_Mapa", datos)
    bpy.context.collection.objects.link(luz)
    luz.location = (0.0, 0.0, 15.0)


def main():
    limpiar_escena()
    candidatas = crear_escena()
    crear_camara()
    crear_luz()

    inicio, fin = obtener_inicio_fin(MAPA)

    print("=" * 62)
    print("CASO 1 - MAPA B CON CANDIDATAS")
    print(f"Dimensiones: {len(MAPA)} x {len(MAPA[0])}")
    print(f"Inicio: {inicio}")
    print(f"Fin: {fin}")
    print(f"|C| = {len(candidatas)}")
    print()
    print("Primeras 10 candidatas:")
    for candidata in candidatas[:10]:
        print(
            f"{candidata['id']} -> "
            f"(fila={candidata['fila']}, columna={candidata['columna']})"
        )
    print("=" * 62)


main()
