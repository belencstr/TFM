import bpy
import sys
from pathlib import Path

# ============================================================
# CASO 1 - VISUALIZACIÓN DE SOLUCIÓN CLÁSICA EN BLENDER
# ============================================================
#
# IMPORTANTE:
# Cuando un script se ejecuta desde el Text Editor de Blender,
# __file__ puede no contener la ruta real del archivo.
#
# Por eso obtenemos la ruta desde el bloque de texto activo:
#     bpy.context.space_data.text.filepath
# ============================================================


def obtener_raiz_proyecto():
    """
    Obtiene la raíz de caso1_colocacion_monedas a partir del
    archivo que está abierto actualmente en el Text Editor.

    Estructura esperada:

    caso1_colocacion_monedas/
    ├── mapas/
    ├── modelo/
    └── visualizacion/
        └── blender_solucion_clasica.py
    """
    espacio = bpy.context.space_data
    texto = getattr(espacio, "text", None)

    if texto is None:
        raise RuntimeError(
            "No se ha podido identificar el script activo de Blender."
        )

    ruta_texto = texto.filepath

    if not ruta_texto:
        raise RuntimeError(
            "El bloque de texto de Blender no tiene una ruta asociada. "
            "Abre el archivo .py desde Scripting > Open en lugar de "
            "copiarlo en un bloque de texto nuevo."
        )

    ruta_script = Path(
        bpy.path.abspath(ruta_texto)
    ).resolve()

    raiz = ruta_script.parent.parent

    print(f"Ruta del script: {ruta_script}")
    print(f"Raíz detectada: {raiz}")

    # Comprobación útil para detectar enseguida una carpeta incorrecta.
    if not (raiz / "mapas" / "mapa_b.py").exists():
        raise RuntimeError(
            "Se ha detectado la raíz del proyecto, pero no existe "
            f"{raiz / 'mapas' / 'mapa_b.py'}. "
            "Comprueba que blender_solucion_clasica.py esté dentro "
            "de la carpeta visualizacion/ del proyecto."
        )

    if not (raiz / "modelo" / "candidatas.py").exists():
        raise RuntimeError(
            "No se encuentra modelo/candidatas.py en la raíz detectada: "
            f"{raiz}"
        )

    return raiz


RAIZ_PROYECTO = obtener_raiz_proyecto()

if str(RAIZ_PROYECTO) not in sys.path:
    sys.path.insert(0, str(RAIZ_PROYECTO))


from mapas.mapa_b import MAPA_B
from modelo.candidatas import obtener_candidatas


# ------------------------------------------------------------
# SOLUCIONES OBTENIDAS
# ------------------------------------------------------------

SOLUCIONES = {
    "sin_dmin": {
        "ids": [
            "C001",
            "C014",
            "C015",
            "C187",
            "C188",
        ],
        "valor_objetivo": 166,
        "separacion_minima": 2,
    },

    "dmin_5": {
        "ids": [
            "C001",
            "C014",
            "C054",
            "C187",
            "C188",
        ],
        "valor_objetivo": 166,
        "separacion_minima": 5,
    },
}


SOLUCION_ACTIVA = "dmin_5"


# ------------------------------------------------------------
# PARÁMETROS VISUALES
# ------------------------------------------------------------

TAM_CELDA = 1.0
ALTURA_SUELO = 0.10
ALTURA_MURO = 1.25

RADIO_MONEDA = 0.28
GROSOR_MONEDA = 0.10
ALTURA_MONEDA = 0.18


def limpiar_escena():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)


def crear_material(nombre, color):
    material = bpy.data.materials.get(nombre)

    if material is None:
        material = bpy.data.materials.new(name=nombre)

    material.diffuse_color = color
    return material


def crear_cubo(nombre, posicion, escala, material):
    bpy.ops.mesh.primitive_cube_add(location=posicion)

    obj = bpy.context.active_object
    obj.name = nombre
    obj.scale = escala
    obj.data.materials.append(material)

    return obj


def coordenadas_blender(fila, columna, filas, columnas):
    offset_x = (columnas - 1) / 2
    offset_y = (filas - 1) / 2

    x = (columna - offset_x) * TAM_CELDA
    y = (offset_y - fila) * TAM_CELDA

    return x, y


def crear_marcador(nombre, x, y, radio, altura, z, material):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=32,
        radius=radio,
        depth=altura,
        location=(x, y, z),
    )

    obj = bpy.context.active_object
    obj.name = nombre
    obj.data.materials.append(material)

    return obj


def crear_moneda(nombre, x, y, material):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=48,
        radius=RADIO_MONEDA,
        depth=GROSOR_MONEDA,
        location=(x, y, ALTURA_MONEDA),
    )

    moneda = bpy.context.active_object
    moneda.name = nombre
    moneda.data.materials.append(material)

    return moneda


def crear_mapa():
    filas = len(MAPA_B)
    columnas = len(MAPA_B[0])

    suelo_mat = crear_material(
        "Material_Suelo",
        (0.20, 0.32, 0.20, 1.0),
    )

    muro_mat = crear_material(
        "Material_Muro",
        (0.18, 0.20, 0.24, 1.0),
    )

    inicio_mat = crear_material(
        "Material_Inicio",
        (0.05, 0.65, 0.12, 1.0),
    )

    fin_mat = crear_material(
        "Material_Fin",
        (0.75, 0.08, 0.06, 1.0),
    )

    for fila, contenido in enumerate(MAPA_B):
        for columna, celda in enumerate(contenido):

            x, y = coordenadas_blender(
                fila,
                columna,
                filas,
                columnas,
            )

            crear_cubo(
                nombre=f"Suelo_{fila}_{columna}",
                posicion=(x, y, -ALTURA_SUELO / 2),
                escala=(
                    TAM_CELDA / 2,
                    TAM_CELDA / 2,
                    ALTURA_SUELO / 2,
                ),
                material=suelo_mat,
            )

            if celda == "#":
                crear_cubo(
                    nombre=f"Muro_{fila}_{columna}",
                    posicion=(x, y, ALTURA_MURO / 2),
                    escala=(
                        TAM_CELDA / 2,
                        TAM_CELDA / 2,
                        ALTURA_MURO / 2,
                    ),
                    material=muro_mat,
                )

            elif celda == "S":
                crear_marcador(
                    nombre="INICIO",
                    x=x,
                    y=y,
                    radio=0.30,
                    altura=0.12,
                    z=0.08,
                    material=inicio_mat,
                )

            elif celda == "E":
                crear_marcador(
                    nombre="FIN",
                    x=x,
                    y=y,
                    radio=0.30,
                    altura=0.12,
                    z=0.08,
                    material=fin_mat,
                )


def crear_solucion():
    if SOLUCION_ACTIVA not in SOLUCIONES:
        raise ValueError(
            f"Solución no válida: {SOLUCION_ACTIVA}"
        )

    solucion = SOLUCIONES[SOLUCION_ACTIVA]

    candidatas = obtener_candidatas(MAPA_B)

    candidatas_por_id = {
        candidata["id"]: candidata
        for candidata in candidatas
    }

    moneda_mat = crear_material(
        "Material_Moneda",
        (0.95, 0.65, 0.05, 1.0),
    )

    filas = len(MAPA_B)
    columnas = len(MAPA_B[0])

    for id_candidata in solucion["ids"]:

        candidata = candidatas_por_id[id_candidata]

        x, y = coordenadas_blender(
            candidata["fila"],
            candidata["columna"],
            filas,
            columnas,
        )

        moneda = crear_moneda(
            nombre=f"Moneda_{id_candidata}",
            x=x,
            y=y,
            material=moneda_mat,
        )

        moneda["candidata"] = id_candidata
        moneda["fila"] = candidata["fila"]
        moneda["columna"] = candidata["columna"]


def crear_camara():
    filas = len(MAPA_B)
    columnas = len(MAPA_B[0])

    datos = bpy.data.cameras.new("Camara_Mapa")
    camara = bpy.data.objects.new("Camara_Mapa", datos)
    bpy.context.collection.objects.link(camara)

    camara.location = (0.0, 0.0, 25.0)
    datos.type = "ORTHO"
    datos.ortho_scale = max(filas, columnas) + 2

    bpy.context.scene.camera = camara


def crear_luz():
    datos = bpy.data.lights.new(
        "Luz_Mapa",
        type="AREA",
    )

    datos.energy = 1800
    datos.shape = "DISK"
    datos.size = 15.0

    luz = bpy.data.objects.new(
        "Luz_Mapa",
        datos,
    )

    bpy.context.collection.objects.link(luz)
    luz.location = (0.0, 0.0, 15.0)


def configurar_escena():
    escena = bpy.context.scene

    escena.render.resolution_x = 900
    escena.render.resolution_y = 900
    escena.render.resolution_percentage = 100

    escena.world.color = (
        0.035,
        0.035,
        0.035,
    )


def imprimir_resumen():
    solucion = SOLUCIONES[SOLUCION_ACTIVA]

    print("=" * 65)
    print("CASO 1 - VISUALIZACIÓN CLÁSICA")
    print(f"Raíz proyecto: {RAIZ_PROYECTO}")
    print(f"Solución activa: {SOLUCION_ACTIVA}")
    print(f"Monedas: {solucion['ids']}")
    print(f"Valor objetivo: {solucion['valor_objetivo']}")
    print(
        f"Separación mínima: "
        f"{solucion['separacion_minima']}"
    )
    print("=" * 65)


def main():
    limpiar_escena()
    crear_mapa()
    crear_solucion()
    crear_camara()
    crear_luz()
    configurar_escena()
    imprimir_resumen()


main()