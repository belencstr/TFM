import bpy
import sys
from pathlib import Path

# Permite importar módulos del proyecto al ejecutar este archivo desde Blender.
RAIZ = Path(bpy.path.abspath("//")).resolve()
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))

from mapas.mapa_a import MAPA_A
from mapas.mapa_b import MAPA_B
from mapas.mapa_c import MAPA_C
from modelo.candidatas import obtener_candidatas, obtener_inicio_fin

MAPAS = {"A": MAPA_A, "B": MAPA_B, "C": MAPA_C}
MAPA_ACTIVO = "B"

TAM_CELDA = 1.0
ALTURA_SUELO = 0.10
ALTURA_MURO = 1.25


def limpiar_escena():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)


def crear_material(nombre, color):
    material = bpy.data.materials.get(nombre)
    if material is None:
        material = bpy.data.materials.new(name=nombre)
    material.diffuse_color = color
    return material


def crear_cubo(nombre, posicion, escala, material):
    bpy.ops.mesh.primitive_cube_add(location=posicion)
    obj = bpy.context.active_object
    obj.name = nombre
    obj.scale = escala
    obj.data.materials.append(material)
    return obj


def crear_marcador(nombre, x, y, material):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=32,
        radius=0.30,
        depth=0.12,
        location=(x, y, 0.08),
    )
    obj = bpy.context.active_object
    obj.name = nombre
    obj.data.materials.append(material)
    return obj


def coordenadas_blender(fila, columna, filas, columnas):
    offset_x = (columnas - 1) / 2
    offset_y = (filas - 1) / 2
    return (
        (columna - offset_x) * TAM_CELDA,
        (offset_y - fila) * TAM_CELDA,
    )


def crear_mapa(mapa):
    filas = len(mapa)
    columnas = len(mapa[0])

    suelo = crear_material("Suelo", (0.20, 0.32, 0.20, 1.0))
    muro = crear_material("Muro", (0.18, 0.20, 0.24, 1.0))
    inicio_mat = crear_material("Inicio", (0.05, 0.65, 0.12, 1.0))
    fin_mat = crear_material("Fin", (0.75, 0.08, 0.06, 1.0))

    for fila, contenido in enumerate(mapa):
        for columna, celda in enumerate(contenido):
            x, y = coordenadas_blender(fila, columna, filas, columnas)

            crear_cubo(
                f"Suelo_{fila}_{columna}",
                (x, y, -ALTURA_SUELO / 2),
                (TAM_CELDA / 2, TAM_CELDA / 2, ALTURA_SUELO / 2),
                suelo,
            )

            if celda == "#":
                crear_cubo(
                    f"Muro_{fila}_{columna}",
                    (x, y, ALTURA_MURO / 2),
                    (TAM_CELDA / 2, TAM_CELDA / 2, ALTURA_MURO / 2),
                    muro,
                )
            elif celda == "S":
                crear_marcador("INICIO", x, y, inicio_mat)
            elif celda == "E":
                crear_marcador("FIN", x, y, fin_mat)


def crear_camara(mapa):
    filas = len(mapa)
    columnas = len(mapa[0])

    datos = bpy.data.cameras.new("Camara_Mapa")
    camara = bpy.data.objects.new("Camara_Mapa", datos)
    bpy.context.collection.objects.link(camara)

    camara.location = (0.0, 0.0, 25.0)
    datos.type = "ORTHO"
    datos.ortho_scale = max(filas, columnas) + 2
    bpy.context.scene.camera = camara


def crear_luz():
    datos = bpy.data.lights.new("Luz_Mapa", type="AREA")
    datos.energy = 1800
    datos.shape = "DISK"
    datos.size = 15.0

    luz = bpy.data.objects.new("Luz_Mapa", datos)
    bpy.context.collection.objects.link(luz)
    luz.location = (0.0, 0.0, 15.0)


def main():
    mapa = MAPAS[MAPA_ACTIVO]

    limpiar_escena()
    crear_mapa(mapa)
    crear_camara(mapa)
    crear_luz()

    candidatas = obtener_candidatas(mapa)
    inicio, fin = obtener_inicio_fin(mapa)

    print("=" * 55)
    print(f"CASO 1 - MAPA {MAPA_ACTIVO}")
    print(f"Dimensiones: {len(mapa)} x {len(mapa[0])}")
    print(f"Inicio: {inicio}")
    print(f"Fin: {fin}")
    print(f"Posiciones candidatas: {len(candidatas)}")
    print("=" * 55)


main()
