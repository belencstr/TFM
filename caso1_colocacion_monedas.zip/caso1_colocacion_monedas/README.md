# Caso 1 — Colocación de monedas sobre un mapa existente

Estado actual del desarrollo.

## Implementado

1. Tres instancias de mapa:
   - Mapa A: espacio abierto.
   - Mapa B: espacio abierto con obstáculos.
   - Mapa C: mapa estructurado.
2. Inicio (`S`) y fin (`E`) del nivel.
3. Todas las celdas `.` se consideran posiciones candidatas.
4. `S` y `E` son transitables, pero no candidatas para monedas.
5. Visualización de los mapas en Blender.
6. Visualización de las posiciones candidatas del Mapa B.

## Estructura actual

```text
caso1_colocacion_monedas/
├── mapas/
│   ├── mapa_a.py
│   ├── mapa_b.py
│   └── mapa_c.py
├── modelo/
│   └── candidatas.py
├── visualizacion/
│   ├── blender_mapa.py
│   └── blender_candidatas.py
└── README.md
```

No se han incluido todavía grafo, distancias, QUBO, solvers ni experimentos.

## Uso en Blender

Para que los imports funcionen de forma sencilla:

1. Abre Blender.
2. Guarda el archivo `.blend` dentro de la carpeta `caso1_colocacion_monedas/`.
3. Abre desde `Scripting` uno de los scripts de `visualizacion/`.
4. Ejecuta `Run Script`.

`blender_mapa.py` permite cambiar `MAPA_ACTIVO` entre `"A"`, `"B"` y `"C"`.

`blender_candidatas.py` muestra las candidatas del Mapa B.
